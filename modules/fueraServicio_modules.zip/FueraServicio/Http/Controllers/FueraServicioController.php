<?php

namespace Modules\Fueraservicio\Http\Controllers;

use Illuminate\Http\Request;
use Pingpong\Modules\Routing\Controller;
use Modules\FueraServicio\Entities\FlotillaSiniestros;
use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Modules\Fueraservicio\Http\Requests\FueraServicioRequest;
use Modules\Flota\Entities\Unidad;
use Carbon\Carbon;

class FueraServicioController extends Controller {

    protected $auth;
    protected $FlotillaSiniestros;

    public function __construct(FlotillaSiniestros $FlotillaSiniestros) {
        $this->auth = Sentinel::getUser();
        $this->FlotillaSiniestros = $FlotillaSiniestros;
    }

    public function index() {
        $FlotillaSiniestros = FlotillaSiniestros::all();
        return view('fueraservicio::siniestros.index', compact('FlotillaSiniestros'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        //all availbale vehicle codes from flotilla_inventario table.
        //Model Modules\Flota\Entities\Unidad
        $claves = Unidad::lists('clave','id');

        return view('fueraservicio::siniestros.create', compact('claves'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(FueraServicioRequest $request) {

        $fillable = $request->only('clave', 'sucursal', 'numSiniestro', 'numReporte', 'inciso', 'poliza', 'tipo_siniestro', 'fecha_del_siniestro', 'comentarios','description');
        //No. of days from the accident
        $fillable['num_dias'] = Carbon::createFromFormat('Y-m-d', $fillable['fecha_del_siniestro'])->diff(new Carbon())->days;
        $this->FlotillaSiniestros->fill($fillable);
        $this->FlotillaSiniestros->save();
        flash()->success('Creación exitosa.');
        return redirect('fueraservicio');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        $claves = Unidad::lists('clave','id');
        //var_dump($claves);die;
        $fueraservicio = FlotillaSiniestros::FindOrFail($id);
        return view('fueraservicio::siniestros.edit', compact('fueraservicio', 'claves'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(FueraServicioRequest $request, $id) {
        $fillable = $request->only('clave', 'sucursal', 'numSiniestro', 'numReporte', 'inciso', 'poliza', 'tipo_siniestro', 'fecha_del_siniestro', 'comentarios', 'description');

        $FlotillaSiniestros = $this->FlotillaSiniestros->find($id);
        //No. of days from the accident
        $fillable['num_dias'] = Carbon::createFromFormat('Y-m-d', $fillable['fecha_del_siniestro'])->diff(new Carbon())->days;
        // fill data
        $FlotillaSiniestros->fill($fillable);
        // save flotilla
        $FlotillaSiniestros->save();
        // message
        flash()->success('Actualización exitosa.');

        return redirect('fueraservicio');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        try {
            $FlotillaSiniestros = $this->FlotillaSiniestros->find($id);
            $FlotillaSiniestros->destroy($id);
            return response()->json(['msg' => 'el registro se elimino exitosamente'], 200);
        } catch (QueryException $e) {
            return response()->json(['msg' => 'No se pudo eliminar el registro'], 202);
        }
    }

}

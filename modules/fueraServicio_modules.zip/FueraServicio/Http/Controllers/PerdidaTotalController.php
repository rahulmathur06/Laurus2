<?php namespace Modules\Fueraservicio\Http\Controllers;

use Pingpong\Modules\Routing\Controller;
use Modules\FueraServicio\Entities\FlotillaPerdidaTotal;
use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Modules\Fueraservicio\Http\Requests\PerdidaTotalRequest;
use Modules\Fueraservicio\Http\Requests\PerdidaTotalEditRequest;
use Modules\User\Entities\User;
use Modules\Roles\Entities\Rol;
use DB;

class PerdidaTotalController extends Controller {
	
	protected $auth;

	public function __construct(FlotillaPerdidaTotal $FlotillaPerdidaTotal){
		$this->FlotillaPerdidaTotal = $FlotillaPerdidaTotal;
		$this->auth = Sentinel::getUser();
	}

	public function index()
	{
		$flotillaPerdidaTotal  = FlotillaPerdidaTotal::all();
		return view('fueraservicio::perdidatotal.index',compact('flotillaPerdidaTotal'));
	}

	public function create(){
		$recuperacion  = array();
		foreach (range(1,100) as $number){
			 $recuperacion [$number]  =  $number ;
		}
		$ciudad = DB::table('tb_plazas')->lists('Nombre','Clave');
		if(Sentinel::hasAccess('task.create')) {
		 $clave = DB::table('flotilla_inventario')->lists('clave','id');
			return view('fueraservicio::perdidatotal.create', compact('clave','recuperacion','ciudad'));
		}
		alert()->error('No tiene permisos para acceder a esta area.', 'Oops!')->persistent('Cerrar');
		return back();
	}

	public function store(PerdidaTotalRequest $request){
		$filleable = $request->only('clave','tipo_siniestro','sucursal','cliente','ciudad','comentarios','fecha_del_siniestro','tipo_siniestro','deducible','recuperacion','numReporte','cobertura','num_contrato','contrato_inicio','contrato_fin','description');
		$this->FlotillaPerdidaTotal->fill($filleable);
		$this->FlotillaPerdidaTotal->save();
		flash()->success('Creación exitosa.');
		return redirect()->to('perdida');
	}

	public function edit($id)
	{
		$flotillaPerdidaTotal = $this->FlotillaPerdidaTotal->find($id);
		$clave = DB::table('flotilla_inventario')->lists('clave','id');
		$ciudad = DB::table('locaciones_plaza')->lists('nombre','id');
		$recuperacion  = array();
		foreach (range(1,100) as $number){
			 $recuperacion [$number]  =  $number ;
		}
		return view('fueraservicio::perdidatotal.edit',compact('flotillaPerdidaTotal','clave','recuperacion','ciudad'));

	}

	public function update(PerdidaTotalEditRequest $request, $id){
		$filleable = $request->only('clave','tipo_siniestro','sucursal','cliente','ciudad','comentarios','fecha_del_siniestro','tipo_siniestro','deducible','recuperacion','numReporte','cobertura','num_contrato','contrato_inicio','contrato_fin','description');
		// search FlotillaPerdidaTotals
		$FlotillaPerdidaTotals = $this->FlotillaPerdidaTotal->find($id);
		
		// fill data
		$FlotillaPerdidaTotals->fill($filleable);
		// save FlotillaPerdidaTotals
		$FlotillaPerdidaTotals->save();

		// message
		flash()->success('Actualización exitosa.');
		return redirect()->to('perdida');

	}

	 /**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
    public function destroy($id) {
        try {
            $FlotillaPerdidaTotals = $this->FlotillaPerdidaTotal->find($id);
            $FlotillaPerdidaTotals->destroy($id);
            return response()->json(['msg' => 'el registro se elimino exitosamente'], 200);
        } catch (QueryException $e) {
            return response()->json(['msg' => 'No se pudo eliminar el registro'], 202);
        }
    }

	
}
<?php

Route::group([ 'namespace' => 'Modules\FueraServicio\Http\Controllers','middleware'=>'authSentinel'], function()
{
	//Route::get('/', 'FueraServicioController@index');
	Route::resource('fueraservicio','FueraServicioController');
	Route::resource('perdida','PerdidaTotalController');
});
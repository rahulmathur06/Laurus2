<?php

Route::group([ 'namespace' => 'Modules\FueraServicio\Http\Controllers','middleware'=>'authSentinel'], function()
{
	Route::post('fueraservicio/movetoperdida','FueraServicioController@moveToPerdidaTotal')->name('fueraservicio.move');
	Route::resource('fueraservicio','FueraServicioController');
	Route::resource('perdida','PerdidaTotalController');


	Route::get('citytobranch','PerdidaTotalController@getCityToBranch');
	Route::get('carcodetodescription','FueraServicioController@getCarcodeToDescription');
	/*
	Route::get('seedsmydata',function ()
	{
		( new \Modules\FueraServicio\Database\Seeders\FueraServicioDatabaseSeeder)->run();
	});
	*/
});
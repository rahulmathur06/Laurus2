<?php namespace Modules\Fueraservicio\Providers;

use Illuminate\Support\ServiceProvider;
use Menu;
use Cartalyst\Sentinel\Native\Facades\Sentinel;

class FueraServicioServiceProvider extends ServiceProvider {

	/**
	 * Indicates if loading of the provider is deferred.
	 *
	 * @var bool
	 */
	protected $defer = false;

	/**
	 * Boot the application events.
	 * 
	 * @return void
	 */
	public function boot()
	{
		$this->registerTranslations();
		$this->registerConfig();
		$this->registerViews();
		//$this->registerMenu();
	}




	/**
	 * Register the service provider.
	 *
	 * @return void
	 */
	public function register()
	{		
		//
	}

	/**
	 * Register config.
	 * 
	 * @return void
	 */
	protected function registerConfig()
	{
		$this->publishes([
		    __DIR__.'/../Config/config.php' => config_path('fueraservicio.php'),
		]);
		$this->mergeConfigFrom(
		    __DIR__.'/../Config/config.php', 'fueraservicio'
		);
	}

	/**
	 * Register views.
	 * 
	 * @return void
	 */
	public function registerViews()
	{
		//$viewPath = base_path('resources/views/modules/fueraservicio');
		$viewPath = base_path('modules/resources/views/fueraservicio');

		$sourcePath = __DIR__.'/../Resources/views';

		$this->publishes([
			$sourcePath => $viewPath
		]);

		$this->loadViewsFrom([$viewPath, $sourcePath], 'fueraservicio');

		/* $this->loadViewsFrom(array_merge(array_map(function ($path) {
			return $path . '/modules/fueraservicio';
		}, \Config::get('view.paths')), [$sourcePath]), 'fueraservicio');
		*/
	}

	/**
	 * Register translations.
	 * 
	 * @return void
	 */
	public function registerTranslations()
	{
		$langPath = base_path('resources/lang/modules/fueraservicio');

		if (is_dir($langPath)) {
			$this->loadTranslationsFrom($langPath, 'fueraservicio');
		} else {
			$this->loadTranslationsFrom(__DIR__ .'/../Resources/lang', 'fueraservicio');
		}
	}

	/**
	 * Get the services provided by the provider.
	 *
	 * @return array
	 */
	public function provides()
	{
		return array();
	}

	public function registerMenu()
    {

        if (!Sentinel::check()) {
            return redirect('login');
        }
        if (Sentinel::hasAccess('flotillas.view') ) {

            $menu = Menu::instance('sidebar-menu');
            $menu->dropdown('flotilla', function ($sub) {
                $sub->dropdown('INVENTARIO', function ($sub) {
                    //$sub->route('locacion.index', 'Oficinas', [], 1, ['icon' => 'fa fa-circle-o']);
                   // $sub->route('destino.index', 'Destinos', [], 2, ['icon' => 'fa fa-circle-o']);
                    //$sub->route('ciudad.index', 'Ciudades', [], 3, ['icon' => 'fa fa-circle-o']);
                });

                $sub->dropdown('SINIESTROS', function ($sub) {
                    $sub->route('fueraservicio.index', 'Fuera de Servicio', [], 1, ['icon' => 'fa fa-circle-o']);
                    $sub->route('perdida.index', 'Perdida Total', [], 2, ['icon' => 'fa fa-circle-o']);
                 
                });


            }, 3, ['icon' => 'fa fa-car']);

        }
    }


}
